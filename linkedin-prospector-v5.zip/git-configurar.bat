@echo off
echo.
echo ========================================
echo  CONFIGURAR GITHUB — Cromosit IT
echo  Execute UMA VEZ por projeto
echo ========================================
echo.

set /p PROJETO="Caminho da pasta do projeto (ex: C:\Users\samue\linkedin-prospector): "
set /p REPO_URL="URL do repositorio GitHub (ex: https://github.com/seuusuario/linkedin-prospector.git): "
set /p NOME="Seu nome para o Git (ex: Samuel Betim): "
set /p EMAIL="Seu email do GitHub: "

cd /d %PROJETO%

:: Configura identidade global do Git
git config --global user.name "%NOME%"
git config --global user.email "%EMAIL%"

:: Inicializa o repositório se necessário
if not exist .git (
    git init
    echo Repositorio Git inicializado!
)

:: Cria .gitignore se não existir
if not exist .gitignore (
    echo node_modules/ > .gitignore
    echo .env >> .gitignore
    echo dist/ >> .gitignore
    echo .DS_Store >> .gitignore
    echo *.log >> .gitignore
    echo Arquivo .gitignore criado!
)

:: Conecta ao GitHub
git remote remove origin 2>nul
git remote add origin %REPO_URL%

:: Primeiro commit
git add -A
git commit -m "Primeiro commit — LinkedIn Prospector Cromosit IT"

:: Envia para o GitHub
git branch -M main
git push -u origin main

echo.
echo ========================================
echo  Configuracao concluida!
echo  Agora use git-salvar.bat para salvar
echo ========================================
echo.
pause
