@echo off
echo.
echo ========================================
echo  SALVAR NO GITHUB — Cromosit IT
echo ========================================
echo.

:: Substitua pelo caminho do seu projeto
set PROJETO=%1
if "%PROJETO%"=="" set PROJETO=C:\Users\samue\linkedin-prospector

cd /d %PROJETO%

:: Verifica se é um repositório Git
if not exist .git (
    echo [ERRO] Esta pasta nao e um repositorio Git ainda.
    echo Execute primeiro: git-configurar.bat
    pause
    exit
)

:: Pede uma mensagem de commit (ou usa automática)
set /p MSG="Mensagem do commit (Enter para usar data/hora): "
if "%MSG%"=="" (
    for /f "tokens=1-5 delims=/ " %%a in ('date /t') do set DATA=%%c-%%b-%%a
    for /f "tokens=1-2 delims=: " %%a in ('time /t') do set HORA=%%a%%b
    set MSG=Auto-save %DATA% %HORA%
)

:: Adiciona todos os arquivos modificados
git add -A

:: Verifica se tem algo para commitar
git diff --staged --quiet
if %errorlevel%==0 (
    echo.
    echo Nenhuma alteracao para salvar. Tudo ja esta atualizado!
    pause
    exit
)

:: Faz o commit
git commit -m "%MSG%"

:: Envia para o GitHub
git push origin main

echo.
echo ========================================
echo  Salvo no GitHub com sucesso!
echo  Mensagem: %MSG%
echo ========================================
echo.
pause
