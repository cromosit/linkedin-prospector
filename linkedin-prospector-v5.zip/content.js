// content.js — LinkedIn Prospector v5
// Captura dados completos incluindo Informações de Contato

function extrairPerfilIndividual() {
  const dados = {}

  // ==========================================
  // NOME — evita capturar "• 1º" ou badges
  // ==========================================
  const nomeSelectors = [
    'h1.text-heading-xlarge',
    'h1.inline.t-24',
    '.pv-text-details__left-panel h1',
    '.ph5 h1',
    'main h1'
  ]
  for (const sel of nomeSelectors) {
    const el = document.querySelector(sel)
    const txt = el?.innerText?.trim()
    if (txt && txt.length > 2 && !txt.includes('•') && !txt.includes('º')) {
      dados.name = txt; break
    }
  }

  // Headline (cargo)
  const headlineSelectors = [
    '.text-body-medium.break-words',
    '.pv-text-details__left-panel .text-body-medium',
    '.ph5 .text-body-medium'
  ]
  for (const sel of headlineSelectors) {
    const el = document.querySelector(sel)
    if (el?.innerText?.trim()) { dados.headline = el.innerText.trim(); break }
  }

  // Localização
  const locationSelectors = [
    '.pv-text-details__left-panel span.text-body-small',
    '.ph5 span.text-body-small.inline'
  ]
  for (const sel of locationSelectors) {
    const el = document.querySelector(sel)
    const txt = el?.innerText?.trim()
    if (txt && !txt.includes('conexões') && !txt.includes('seguidores') && txt.length > 2) {
      dados.location = txt; break
    }
  }

  // Empresa atual
  const empresaSelectors = [
    '.pv-text-details__right-panel .hoverable-link-text span',
    '.pv-text-details__right-panel span.t-14'
  ]
  for (const sel of empresaSelectors) {
    const el = document.querySelector(sel)
    if (el?.innerText?.trim()) { dados.company = el.innerText.trim(); break }
  }

  // Foto
  const fotoSelectors = [
    '.pv-top-card-profile-picture__image--show',
    'img.pv-top-card-profile-picture__image',
    'img[class*="profile-picture"]'
  ]
  for (const sel of fotoSelectors) {
    const el = document.querySelector(sel)
    if (el?.src && !el.src.includes('ghost')) { dados.profile_picture = el.src; break }
  }

  // ==========================================
  // INFORMAÇÕES DE CONTATO
  // Abre o painel de contato se disponível
  // ==========================================
  extrairInfoContato(dados)

  // Grau de conexão
  const bodyTxt = document.body.innerText || ''
  if (bodyTxt.includes('• 1º') || bodyTxt.includes('1st')) dados.connection_degree = '1'
  else if (bodyTxt.includes('• 2º') || bodyTxt.includes('2nd')) dados.connection_degree = '2'
  else dados.connection_degree = '3'

  // Conexões em comum
  const mutualMatch = bodyTxt.match(/(\d+)\s+conex[õo]es? em comum/i)
  if (mutualMatch) dados.mutual_connections = mutualMatch[0]

  // Seguidores
  const seguidoresMatch = bodyTxt.match(/([\d.,]+)\s+seguidores?/i)
  if (seguidoresMatch) dados.followers = seguidoresMatch[0]

  // Sobre (bio)
  const sobreEl = document.querySelector('#about ~ div .pv-shared-text-with-see-more span') ||
                  document.querySelector('.pv-shared-text-with-see-more span[aria-hidden="true"]')
  if (sobreEl?.innerText) dados.about = sobreEl.innerText.trim().substring(0, 1000)

  // URL e ID
  dados.linkedin_url = window.location.href.split('?')[0]
  const urlMatch = window.location.pathname.match(/\/in\/([^/]+)/)
  dados.linkedin_id = urlMatch ? urlMatch[1] : ''

  dados.temperature = dados.connection_degree === '1' ? 'quente' :
                      dados.connection_degree === '2' ? 'morno' : 'frio'
  dados.source = 'chrome_extension'

  return dados
}

// ==========================================
// EXTRAI INFORMAÇÕES DE CONTATO DO PAINEL
// (visível quando o painel de contato está aberto)
// ==========================================
function extrairInfoContato(dados) {
  // Email
  const emailEl = document.querySelector('a[href^="mailto:"]')
  if (emailEl) dados.email = emailEl.href.replace('mailto:', '').trim()

  // Telefone
  const phoneEl = document.querySelector('a[href^="tel:"]')
  if (phoneEl) dados.phone = phoneEl.href.replace('tel:', '').trim()

  // Website
  const websiteEl = document.querySelector('a[data-field="website_url"]') ||
                    document.querySelector('section.pv-contact-info a[href*="http"]:not([href*="linkedin"])')
  if (websiteEl) dados.website = websiteEl.href

  // Tenta extrair do modal de contato se estiver aberto
  const contactModal = document.querySelector('.pv-contact-info__contact-type')
  if (contactModal) {
    const items = document.querySelectorAll('.pv-contact-info__contact-type')
    items.forEach(item => {
      const label = item.querySelector('h3')?.innerText?.toLowerCase() || ''
      const value = item.querySelector('a, span.t-14')

      if (label.includes('email') || label.includes('e-mail')) {
        if (!dados.email && value) dados.email = value.innerText?.trim() || value.href?.replace('mailto:', '')
      }
      if (label.includes('telefone') || label.includes('phone') || label.includes('celular')) {
        if (!dados.phone && value) dados.phone = value.innerText?.trim()
      }
      if (label.includes('website') || label.includes('site')) {
        if (!dados.website && value) dados.website = value.href || value.innerText?.trim()
      }
      if (label.includes('aniversário') || label.includes('birthday') || label.includes('nascimento')) {
        if (value) dados.birthday = value.innerText?.trim()
      }
      if (label.includes('conectado') || label.includes('connected') || label.includes('conexão')) {
        if (value) dados.connected_since = value.innerText?.trim()
      }
    })
  }
}

// ==========================================
// EXTRAI LISTA DE BUSCA — v5
// ==========================================
function extrairListaDeBusca() {
  const leads = []
  const vistos = new Set()
  const blacklist = ['messaging','notifications','jobs','feed','mynetwork','search','company','school','groups','events','learning','premium','sales','recruiter','talent']
  const todosLinks = document.querySelectorAll('a[href*="/in/"]')

  todosLinks.forEach(link => {
    try {
      const href = link.href || ''
      if (!href.includes('/in/')) return
      const match = href.match(/\/in\/([a-zA-Z0-9_-]+)/)
      if (!match) return
      const linkedin_id = match[1]
      if (vistos.has(linkedin_id)) return
      if (blacklist.some(b => linkedin_id.includes(b))) return
      if (linkedin_id.length < 3) return
      vistos.add(linkedin_id)

      const lead = { linkedin_id, linkedin_url: `https://www.linkedin.com/in/${linkedin_id}`, source: 'chrome_extension' }

      let container = link
      for (let i = 0; i < 10; i++) {
        container = container.parentElement
        if (!container || container.tagName === 'BODY') break
        const texto = container.innerText || ''

        if (!lead.name) {
          const nomeSpan = link.querySelector('span[aria-hidden="true"]') || link.querySelector('span')
          const nomeTexto = nomeSpan?.innerText?.trim() || link.innerText?.trim()
          if (nomeTexto && nomeTexto.length > 1 && nomeTexto.length < 80 &&
              !nomeTexto.includes('•') && !nomeTexto.includes('º')) {
            lead.name = nomeTexto
          }
        }

        if (!lead.headline) {
          const subs = container.querySelectorAll('[class*="subtitle"],[class*="headline"],.t-14.t-black')
          subs.forEach(s => {
            const t = s.innerText?.trim()
            if (t && t.length > 3 && t.length < 200 && !lead.headline &&
                !t.includes('conexões') && !t.includes('seguidores') && !t.includes('•')) {
              lead.headline = t
            }
          })
        }

        if (!lead.profile_picture) {
          const img = container.querySelector('img')
          if (img?.src && img.src.startsWith('https') && !img.src.includes('ghost') &&
              (img.src.includes('media') || img.src.includes('profile'))) {
            lead.profile_picture = img.src
          }
        }

        if (!lead.connection_degree) {
          if (texto.includes('• 1º') || texto.includes('1st')) lead.connection_degree = '1'
          else if (texto.includes('• 2º') || texto.includes('2nd')) lead.connection_degree = '2'
          else if (texto.includes('3º e +') || texto.includes('3rd') || texto.includes('• 3')) lead.connection_degree = '3'
        }

        if (!lead.mutual_connections) {
          const m = texto.match(/(\d+)\s+conex[õo]es? em comum/i)
          if (m) lead.mutual_connections = m[0]
        }

        if (!lead.location && texto.length < 500) {
          const l = texto.match(/[A-ZÀ-Ü][a-zà-ü]+(?: [A-ZÀ-Ü][a-zà-ü]+)*,\s*(?:Brasil|[A-Z][a-zà-ü]+)/u)
          if (l) lead.location = l[0]
        }

        if (lead.name && lead.connection_degree) break
      }

      if (!lead.name || lead.name.length < 2) return
      if (lead.name.toLowerCase().includes('linkedin')) return
      if (lead.name.includes('•') || lead.name.includes('º')) return

      if (lead.headline && !lead.company) {
        if (lead.headline.includes(' · ')) {
          lead.company = lead.headline.split(' · ').pop().trim()
        } else if (lead.headline.includes(' na ')) {
          lead.company = lead.headline.split(' na ').pop().split('|')[0].trim()
        } else if (lead.headline.includes(' at ')) {
          lead.company = lead.headline.split(' at ').pop().split('|')[0].trim()
        }
      }

      lead.connection_degree = lead.connection_degree || '3'
      lead.temperature = lead.connection_degree === '1' ? 'quente' :
                         lead.connection_degree === '2' ? 'morno' : 'frio'
      leads.push(lead)
    } catch(e) {}
  })

  return leads
}

function detectarTipoPagina() {
  const url = window.location.href
  if (url.includes('/search/results/')) return 'busca'
  if (url.includes('/in/')) return 'perfil'
  return 'outro'
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'detectarPagina') {
    const tipo = detectarTipoPagina()
    let preview = null
    if (tipo === 'perfil') { const dados = extrairPerfilIndividual(); preview = { name: dados.name } }
    else if (tipo === 'busca') { const leads = extrairListaDeBusca(); preview = { total: leads.length } }
    sendResponse({ tipo, preview })
  }
  if (request.action === 'extrairPerfil') { sendResponse({ sucesso: true, dados: extrairPerfilIndividual() }) }
  if (request.action === 'extrairBusca') { const leads = extrairListaDeBusca(); sendResponse({ sucesso: true, leads, total: leads.length }) }
  return true
})
