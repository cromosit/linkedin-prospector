import { useState, useEffect } from 'react'
import Sidebar from '../components/Sidebar'
import api from '../api'

const STATUS = {
  novo: { label: 'Novo', color: 'var(--blue-bright)' },
  contatado: { label: 'Contatado', color: 'var(--yellow)' },
  respondeu: { label: 'Respondeu', color: 'var(--orange)' },
  em_negociacao: { label: 'Negociando', color: 'var(--orange)' },
  fechado: { label: 'Fechado', color: 'var(--green)' },
  descartado: { label: 'Descartado', color: 'var(--red)' }
}
const TEMP = {
  quente: { label: '🔥 Quente', color: 'var(--red)' },
  morno: { label: '⚡ Morno', color: 'var(--orange)' },
  frio: { label: '❄️ Frio', color: 'var(--blue-bright)' }
}
const GRAU = {
  '1': { label: '🟢 1º', color: 'var(--green)', desc: 'Conexão direta' },
  '2': { label: '🔵 2º', color: 'var(--blue-bright)', desc: 'Amigo de amigo' },
  '3': { label: '⚪ 3º', color: 'var(--text3)', desc: 'Fora da rede' }
}

export default function Leads() {
  const [leads, setLeads] = useState([])
  const [loading, setLoading] = useState(true)
  const [busca, setBusca] = useState('')
  const [filtroStatus, setFiltroStatus] = useState('')
  const [filtroTemp, setFiltroTemp] = useState('')
  const [filtroGrau, setFiltroGrau] = useState('')
  const [modal, setModal] = useState(false)
  const [leadSel, setLeadSel] = useState(null)
  const [gerandoMsg, setGerandoMsg] = useState(false)
  const [tipoMsg, setTipoMsg] = useState('conexao')
  const [msgGerada, setMsgGerada] = useState('')
  const [enviando, setEnviando] = useState(false)
  const [excluindo, setExcluindo] = useState(null)
  const [salvando, setSalvando] = useState(false)
  const [form, setForm] = useState({
    name: '', headline: '', company: '', location: '',
    linkedin_url: '', email: '', phone: '', website: '',
    birthday: '', connected_since: '', mutual_connections: '',
    about: '', service_interest: '',
    temperature: 'frio', notes: '', source: 'manual', connection_degree: '3'
  })

  useEffect(() => { carregarLeads() }, [busca, filtroStatus, filtroTemp, filtroGrau])

  const carregarLeads = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (busca) params.set('search', busca)
      if (filtroStatus) params.set('status', filtroStatus)
      if (filtroTemp) params.set('temperature', filtroTemp)
      if (filtroGrau) params.set('connection_degree', filtroGrau)
      params.set('limit', '50')
      const res = await api.get(`/api/leads?${params}`)
      setLeads(res.data.leads || [])
    } catch (err) { console.error(err) }
    finally { setLoading(false) }
  }

  const salvarLead = async () => {
    if (!form.name.trim()) return alert('Nome é obrigatório')
    setSalvando(true)
    try {
      if (leadSel) await api.put(`/api/leads/${leadSel.id}`, form)
      else await api.post('/api/leads', form)
      setModal(false); resetForm(); carregarLeads()
    } catch (err) { alert('Erro ao salvar lead') }
    finally { setSalvando(false) }
  }

  const excluirLead = async (id, nome) => {
    if (!confirm(`Excluir ${nome}? Esta ação não pode ser desfeita.`)) return
    setExcluindo(id)
    try {
      await api.delete(`/api/leads/${id}`)
      carregarLeads()
    } catch (err) { alert('Erro ao excluir lead') }
    finally { setExcluindo(null) }
  }

  const atualizarStatus = async (id, status) => {
    try { await api.put(`/api/leads/${id}`, { status }); carregarLeads() } catch (err) { console.error(err) }
  }

  const gerarMensagem = async (lead, tipo) => {
    setLeadSel(lead); setMsgGerada(''); setGerandoMsg(true); setTipoMsg(tipo || 'conexao')
    try {
      const res = await api.post(`/api/leads/${lead.id}/gerar-mensagem`, {
        tipo: tipo || (lead.connection_degree === '1' ? 'primeiro_contato' : lead.connection_degree === '2' ? 'conexao_com_comum' : 'conexao')
      })
      setMsgGerada(res.data.mensagem)
    } catch (err) { setMsgGerada('Erro ao gerar mensagem. Verifique a chave da API.') }
    finally { setGerandoMsg(false) }
  }

  const enviarWhatsapp = async (telefoneOverride) => {
    if (!leadSel || !msgGerada) return
    const telefone = telefoneOverride || leadSel.phone || prompt('Telefone do lead (ex: 5541999999999):')
    if (!telefone) return
    setEnviando(true)
    try {
      await api.post(`/api/leads/${leadSel.id}/enviar-whatsapp`, { telefone, mensagem: msgGerada })
      alert('✅ Mensagem enviada via WhatsApp!')
      carregarLeads()
    } catch (err) { alert('Erro: ' + (err.response?.data?.error || err.message)) }
    finally { setEnviando(false) }
  }

  const resetForm = () => {
    setLeadSel(null); setMsgGerada('')
    setForm({ name: '', headline: '', company: '', location: '', linkedin_url: '', email: '', phone: '', website: '', birthday: '', connected_since: '', mutual_connections: '', about: '', service_interest: '', temperature: 'frio', notes: '', source: 'manual', connection_degree: '3' })
  }

  const abrirEditar = (lead) => {
    setLeadSel(lead)
    setForm({
      name: lead.name || '', headline: lead.headline || '', company: lead.company || '',
      location: lead.location || '', linkedin_url: lead.linkedin_url || '',
      email: lead.email || '', phone: lead.phone || '', website: lead.website || '',
      birthday: lead.birthday || '', connected_since: lead.connected_since || '',
      mutual_connections: lead.mutual_connections || '', about: lead.about || '',
      service_interest: lead.service_interest || '', temperature: lead.temperature || 'frio',
      notes: lead.notes || '', source: lead.source || 'manual',
      connection_degree: lead.connection_degree || '3'
    })
    setMsgGerada(lead.ai_message || '')
    setModal(true)
  }

  const S = {
    layout: { display: 'flex', minHeight: '100vh', background: 'var(--bg)' },
    main: { flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto' },
    header: { padding: '24px 32px 18px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' },
    title: { fontSize: '22px', fontWeight: '700', letterSpacing: '-0.03em' },
    subtitle: { fontSize: '13px', color: 'var(--text2)', marginTop: '2px' },
    toolbar: { padding: '12px 32px', borderBottom: '1px solid var(--border)', display: 'flex', gap: '8px', flexWrap: 'wrap' },
    input: { background: 'var(--bg3)', border: '1px solid var(--border)', color: 'var(--text)', padding: '7px 12px', fontSize: '13px', outline: 'none', flex: 1, minWidth: '180px' },
    select: { background: 'var(--bg3)', border: '1px solid var(--border)', color: 'var(--text)', padding: '7px 10px', fontSize: '13px', outline: 'none', cursor: 'pointer' },
    addBtn: { padding: '7px 18px', background: 'var(--blue)', border: 'none', color: '#fff', fontSize: '13px', fontWeight: '600', cursor: 'pointer' },
    content: { padding: '20px 32px', flex: 1 },
    table: { width: '100%', borderCollapse: 'collapse' },
    th: { padding: '9px 12px', textAlign: 'left', fontSize: '11px', fontWeight: '600', color: 'var(--text3)', letterSpacing: '0.08em', textTransform: 'uppercase', borderBottom: '1px solid var(--border)' },
    td: { padding: '10px 12px', fontSize: '13px', borderBottom: '1px solid var(--border)', verticalAlign: 'middle' },
    badge: (color) => ({ display: 'inline-block', padding: '2px 7px', background: color + '18', border: `1px solid ${color}40`, color, fontSize: '11px', fontWeight: '600' }),
    btn: (color) => ({ padding: '4px 8px', border: `1px solid ${color}40`, background: 'transparent', color, fontSize: '11px', cursor: 'pointer', transition: 'all 0.15s' }),
    btnDel: { padding: '4px 8px', border: '1px solid rgba(255,59,92,0.3)', background: 'transparent', color: 'var(--red)', fontSize: '11px', cursor: 'pointer' },
    empty: { padding: '60px', textAlign: 'center', color: 'var(--text3)' },
    overlay: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, backdropFilter: 'blur(4px)' },
    modal: { background: 'var(--bg2)', border: '1px solid var(--border)', width: '620px', maxWidth: '95vw', maxHeight: '92vh', overflow: 'auto', animation: 'fadeIn 0.2s ease' },
    modalHeader: { padding: '16px 22px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'sticky', top: 0, background: 'var(--bg2)', zIndex: 1 },
    modalTitle: { fontSize: '15px', fontWeight: '700' },
    modalBody: { padding: '20px 22px' },
    section: { fontSize: '11px', fontWeight: '600', color: 'var(--blue-bright)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '12px', marginTop: '20px', paddingBottom: '6px', borderBottom: '1px solid var(--border)' },
    formRow: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' },
    formRow3: { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px' },
    formGroup: { marginBottom: '12px' },
    label: { display: 'block', fontSize: '11px', fontWeight: '600', color: 'var(--text3)', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '4px' },
    formInput: { width: '100%', background: 'var(--bg3)', border: '1px solid var(--border)', color: 'var(--text)', padding: '7px 10px', fontSize: '13px', outline: 'none' },
    textarea: { width: '100%', background: 'var(--bg3)', border: '1px solid var(--border)', color: 'var(--text)', padding: '7px 10px', fontSize: '13px', outline: 'none', resize: 'vertical', minHeight: '64px', fontFamily: 'var(--font)' },
    grauBtns: { display: 'flex', gap: '6px' },
    grauBtn: (active, color) => ({ padding: '6px 14px', border: `1px solid ${active ? color : 'var(--border)'}`, background: active ? color + '20' : 'transparent', color: active ? color : 'var(--text2)', fontSize: '12px', fontWeight: active ? '600' : '400', cursor: 'pointer', transition: 'all 0.15s' }),
    msgBox: { background: 'var(--bg)', border: '1px solid var(--blue)', padding: '12px', fontSize: '13px', color: 'var(--text)', lineHeight: '1.6', marginTop: '10px' },
    aiActions: { display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '8px' },
    aiBtn: (color) => ({ padding: '7px 12px', background: 'transparent', border: `1px solid ${color}40`, color, fontSize: '12px', cursor: 'pointer', transition: 'all 0.15s' }),
    modalFooter: { padding: '14px 22px', borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', gap: '10px', position: 'sticky', bottom: 0, background: 'var(--bg2)' },
    cancelBtn: { padding: '8px 18px', background: 'transparent', border: '1px solid var(--border)', color: 'var(--text2)', fontSize: '13px', cursor: 'pointer' },
    saveBtn: { padding: '8px 22px', background: 'var(--blue)', border: 'none', color: '#fff', fontSize: '13px', fontWeight: '600', cursor: 'pointer' },
  }

  const tiposMensagem = [
    { value: 'conexao', label: '🔗 Conexão' },
    { value: 'conexao_com_comum', label: '👥 Conexão c/ comum' },
    { value: 'primeiro_contato', label: '💬 1º Contato' },
    { value: 'follow_up', label: '🔄 Follow-up' },
    { value: 'whatsapp', label: '📱 WhatsApp' },
  ]

  return (
    <div style={S.layout}>
      <Sidebar />
      <div style={S.main}>
        <div style={S.header}>
          <div>
            <h1 style={S.title}>Leads</h1>
            <p style={S.subtitle}>{leads.length} lead{leads.length !== 1 ? 's' : ''} encontrado{leads.length !== 1 ? 's' : ''}</p>
          </div>
          <button style={S.addBtn} onClick={() => { resetForm(); setModal(true) }}>+ Novo Lead</button>
        </div>

        <div style={S.toolbar}>
          <input style={S.input} placeholder="Buscar por nome, empresa ou cargo..." value={busca} onChange={e => setBusca(e.target.value)} />
          <select style={S.select} value={filtroStatus} onChange={e => setFiltroStatus(e.target.value)}>
            <option value="">Todos os status</option>
            {Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
          <select style={S.select} value={filtroTemp} onChange={e => setFiltroTemp(e.target.value)}>
            <option value="">Temperatura</option>
            <option value="quente">🔥 Quente</option>
            <option value="morno">⚡ Morno</option>
            <option value="frio">❄️ Frio</option>
          </select>
          <select style={S.select} value={filtroGrau} onChange={e => setFiltroGrau(e.target.value)}>
            <option value="">Grau</option>
            <option value="1">🟢 1º Grau</option>
            <option value="2">🔵 2º Grau</option>
            <option value="3">⚪ 3º Grau</option>
          </select>
        </div>

        <div style={S.content}>
          {loading ? <div style={S.empty}>Carregando leads...</div> : leads.length === 0 ? (
            <div style={S.empty}>
              <div style={{ fontSize: '32px', marginBottom: '12px' }}>◈</div>
              Nenhum lead encontrado.<br />
              <span style={{ color: 'var(--blue-bright)', cursor: 'pointer', marginTop: '8px', display: 'inline-block' }} onClick={() => { resetForm(); setModal(true) }}>
                + Adicionar primeiro lead
              </span>
            </div>
          ) : (
            <table style={S.table}>
              <thead>
                <tr>{['Nome / Cargo', 'Empresa', 'Contato', 'Grau', 'Status', 'Temp.', 'Ações'].map(h => <th key={h} style={S.th}>{h}</th>)}</tr>
              </thead>
              <tbody>
                {leads.map((lead, i) => (
                  <tr key={lead.id} style={{ animation: `fadeIn 0.3s ease ${i * 0.02}s both` }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--bg3)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                  >
                    <td style={S.td}>
                      <div style={{ fontWeight: '500' }}>{lead.name}</div>
                      {lead.headline && <div style={{ fontSize: '11px', color: 'var(--text2)', marginTop: '1px' }}>{lead.headline.substring(0, 55)}{lead.headline.length > 55 ? '...' : ''}</div>}
                    </td>
                    <td style={S.td}>
                      <div>{lead.company || '—'}</div>
                      {lead.location && <div style={{ fontSize: '11px', color: 'var(--text3)' }}>{lead.location}</div>}
                    </td>
                    <td style={S.td}>
                      {lead.phone && <div style={{ fontSize: '11px', color: 'var(--text2)' }}>📱 {lead.phone}</div>}
                      {lead.email && <div style={{ fontSize: '11px', color: 'var(--text2)' }}>✉ {lead.email}</div>}
                      {!lead.phone && !lead.email && <span style={{ color: 'var(--text3)', fontSize: '11px' }}>—</span>}
                    </td>
                    <td style={S.td}>
                      <span style={S.badge(GRAU[lead.connection_degree]?.color || 'var(--text3)')}>
                        {GRAU[lead.connection_degree]?.label || '—'}
                      </span>
                      {lead.mutual_connections && <div style={{ fontSize: '10px', color: 'var(--text3)', marginTop: '2px' }}>👥 {lead.mutual_connections}</div>}
                    </td>
                    <td style={S.td}>
                      <select style={{ ...S.select, padding: '3px 7px', fontSize: '11px' }} value={lead.status} onChange={e => atualizarStatus(lead.id, e.target.value)}>
                        {Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                      </select>
                    </td>
                    <td style={S.td}>
                      <span style={S.badge(TEMP[lead.temperature]?.color || 'var(--text2)')}>
                        {TEMP[lead.temperature]?.label || lead.temperature}
                      </span>
                    </td>
                    <td style={S.td}>
                      <div style={{ display: 'flex', gap: '3px', flexWrap: 'wrap' }}>
                        <button style={S.btn('var(--text2)')} onClick={() => abrirEditar(lead)}>✏ Editar</button>
                        <button style={S.btn('var(--blue-bright)')} onClick={() => { setLeadSel(lead); setMsgGerada(''); gerarMensagem(lead) }}>✦ IA</button>
                        {lead.linkedin_url && (
                          <a href={lead.linkedin_url} target="_blank" rel="noopener noreferrer">
                            <button style={S.btn('var(--blue)')}>in</button>
                          </a>
                        )}
                        <button style={S.btnDel} disabled={excluindo === lead.id} onClick={() => excluirLead(lead.id, lead.name)}>
                          {excluindo === lead.id ? '...' : '🗑'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Modal de IA rápida */}
      {msgGerada !== '' && !modal && leadSel && (
        <div style={S.overlay} onClick={() => { setMsgGerada(''); setLeadSel(null) }}>
          <div style={{ ...S.modal, width: '520px' }} onClick={e => e.stopPropagation()}>
            <div style={S.modalHeader}>
              <div style={S.modalTitle}>✦ Mensagem — {leadSel?.name}</div>
              <button style={{ background: 'none', border: 'none', color: 'var(--text2)', fontSize: '18px', cursor: 'pointer' }} onClick={() => { setMsgGerada(''); setLeadSel(null) }}>✕</button>
            </div>
            <div style={{ padding: '20px 22px' }}>
              {/* Seletor de tipo de mensagem */}
              <div style={{ display: 'flex', gap: '6px', marginBottom: '12px', flexWrap: 'wrap' }}>
                {tiposMensagem.map(t => (
                  <button key={t.value} style={{ ...S.aiBtn(tipoMsg === t.value ? 'var(--blue-bright)' : 'var(--text3)'), background: tipoMsg === t.value ? 'var(--blue-glow)' : 'transparent', fontWeight: tipoMsg === t.value ? '600' : '400' }}
                    onClick={() => { setTipoMsg(t.value); gerarMensagem(leadSel, t.value) }}>
                    {t.label}
                  </button>
                ))}
              </div>

              {gerandoMsg ? (
                <div style={{ textAlign: 'center', padding: '28px', color: 'var(--text2)' }}>
                  <div style={{ fontSize: '24px', animation: 'pulse 1s infinite', marginBottom: '8px' }}>✦</div>
                  Gerando mensagem com IA...
                </div>
              ) : (
                <>
                  <div style={S.msgBox}>{msgGerada}</div>
                  <div style={S.aiActions}>
                    <button style={S.aiBtn('var(--text2)')} onClick={() => { navigator.clipboard.writeText(msgGerada); alert('Copiado!') }}>📋 Copiar</button>
                    <button style={S.aiBtn('var(--green)')} onClick={() => enviarWhatsapp()} disabled={enviando}>
                      {enviando ? '⟳ Enviando...' : '📱 Enviar WhatsApp'}
                    </button>
                    <button style={S.aiBtn('var(--blue-bright)')} onClick={() => gerarMensagem(leadSel, tipoMsg)} disabled={gerandoMsg}>
                      🔄 Regenerar
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal criar/editar */}
      {modal && (
        <div style={S.overlay} onClick={() => { setModal(false); resetForm() }}>
          <div style={S.modal} onClick={e => e.stopPropagation()}>
            <div style={S.modalHeader}>
              <div style={S.modalTitle}>{leadSel ? `Editar — ${leadSel.name}` : 'Novo Lead'}</div>
              <button style={{ background: 'none', border: 'none', color: 'var(--text2)', fontSize: '18px', cursor: 'pointer' }} onClick={() => { setModal(false); resetForm() }}>✕</button>
            </div>

            <div style={S.modalBody}>
              {/* IDENTIFICAÇÃO */}
              <div style={S.section}>Identificação</div>
              <div style={S.formRow}>
                <div style={S.formGroup}><label style={S.label}>Nome *</label><input style={S.formInput} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="João Silva" /></div>
                <div style={S.formGroup}><label style={S.label}>Cargo / Headline</label><input style={S.formInput} value={form.headline} onChange={e => setForm({ ...form, headline: e.target.value })} placeholder="Gerente de TI" /></div>
              </div>
              <div style={S.formRow}>
                <div style={S.formGroup}><label style={S.label}>Empresa</label><input style={S.formInput} value={form.company} onChange={e => setForm({ ...form, company: e.target.value })} placeholder="Empresa Ltda" /></div>
                <div style={S.formGroup}><label style={S.label}>Localização</label><input style={S.formInput} value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="Curitiba, PR" /></div>
              </div>
              <div style={S.formGroup}><label style={S.label}>URL do LinkedIn</label><input style={S.formInput} value={form.linkedin_url} onChange={e => setForm({ ...form, linkedin_url: e.target.value })} placeholder="https://linkedin.com/in/..." /></div>

              {/* CONTATO */}
              <div style={S.section}>Informações de Contato</div>
              <div style={S.formRow}>
                <div style={S.formGroup}><label style={S.label}>Email</label><input style={S.formInput} value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="email@empresa.com" /></div>
                <div style={S.formGroup}><label style={S.label}>Telefone / WhatsApp</label><input style={S.formInput} value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="(41) 99999-9999" /></div>
              </div>
              <div style={S.formRow}>
                <div style={S.formGroup}><label style={S.label}>Website</label><input style={S.formInput} value={form.website} onChange={e => setForm({ ...form, website: e.target.value })} placeholder="https://empresa.com.br" /></div>
                <div style={S.formGroup}><label style={S.label}>Aniversário</label><input style={S.formInput} value={form.birthday} onChange={e => setForm({ ...form, birthday: e.target.value })} placeholder="15 de março" /></div>
              </div>
              <div style={S.formRow}>
                <div style={S.formGroup}><label style={S.label}>Conexão desde</label><input style={S.formInput} value={form.connected_since} onChange={e => setForm({ ...form, connected_since: e.target.value })} placeholder="Janeiro 2024" /></div>
                <div style={S.formGroup}><label style={S.label}>Conexões em comum</label><input style={S.formInput} value={form.mutual_connections} onChange={e => setForm({ ...form, mutual_connections: e.target.value })} placeholder="25 conexões em comum" /></div>
              </div>

              {/* QUALIFICAÇÃO */}
              <div style={S.section}>Qualificação</div>

              {/* Grau de conexão — BOTÕES */}
              <div style={S.formGroup}>
                <label style={S.label}>Grau de Conexão</label>
                <div style={S.grauBtns}>
                  {Object.entries(GRAU).map(([k, v]) => (
                    <button key={k} style={S.grauBtn(form.connection_degree === k, v.color)}
                      onClick={() => setForm({ ...form, connection_degree: k, temperature: k === '1' ? 'quente' : k === '2' ? 'morno' : 'frio' })}>
                      {v.label} <span style={{ fontSize: '10px', opacity: 0.7 }}>{v.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div style={S.formRow}>
                <div style={S.formGroup}><label style={S.label}>Temperatura</label>
                  <select style={{ ...S.formInput, cursor: 'pointer' }} value={form.temperature} onChange={e => setForm({ ...form, temperature: e.target.value })}>
                    <option value="frio">❄️ Frio</option><option value="morno">⚡ Morno</option><option value="quente">🔥 Quente</option>
                  </select>
                </div>
                <div style={S.formGroup}><label style={S.label}>Origem</label>
                  <select style={{ ...S.formInput, cursor: 'pointer' }} value={form.source} onChange={e => setForm({ ...form, source: e.target.value })}>
                    <option value="manual">Manual</option>
                    <option value="chrome_extension">Extensão Chrome</option>
                    <option value="linkedin_login">LinkedIn Login</option>
                    <option value="importacao">Importação</option>
                  </select>
                </div>
              </div>

              {/* Interesse no serviço */}
              <div style={S.formGroup}>
                <label style={S.label}>🎯 O que este lead precisa? (Interesse identificado)</label>
                <input style={S.formInput} value={form.service_interest} onChange={e => setForm({ ...form, service_interest: e.target.value })} placeholder="Ex: Treinamento SAP MM para equipe de compras / Consultoria go-live SAP" />
              </div>

              {/* Sobre */}
              <div style={S.formGroup}><label style={S.label}>Sobre (Bio do LinkedIn)</label><textarea style={{ ...S.textarea, minHeight: '80px' }} value={form.about} onChange={e => setForm({ ...form, about: e.target.value })} placeholder="Resumo do perfil do LinkedIn..." /></div>

              {/* Notas */}
              <div style={S.formGroup}><label style={S.label}>Notas Internas</label><textarea style={S.textarea} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Observações, contexto, próximos passos..." /></div>

              {/* Geração de mensagem */}
              {leadSel && (
                <>
                  <div style={S.section}>✦ Mensagem com IA</div>

                  {/* Seletor de tipo */}
                  <div style={{ display: 'flex', gap: '6px', marginBottom: '10px', flexWrap: 'wrap' }}>
                    {tiposMensagem.map(t => (
                      <button key={t.value} style={{ ...S.aiBtn(tipoMsg === t.value ? 'var(--blue-bright)' : 'var(--text3)'), background: tipoMsg === t.value ? 'var(--blue-glow)' : 'transparent', fontWeight: tipoMsg === t.value ? '600' : '400' }}
                        onClick={() => setTipoMsg(t.value)}>
                        {t.label}
                      </button>
                    ))}
                  </div>

                  <div style={S.aiActions}>
                    <button style={S.aiBtn('var(--blue-bright)')} onClick={() => gerarMensagem(leadSel, tipoMsg)} disabled={gerandoMsg}>
                      {gerandoMsg ? '⟳ Gerando...' : '✦ Gerar mensagem'}
                    </button>
                    {msgGerada && (
                      <>
                        <button style={S.aiBtn('var(--text2)')} onClick={() => { navigator.clipboard.writeText(msgGerada); alert('Copiado!') }}>📋 Copiar</button>
                        <button style={S.aiBtn('var(--green)')} onClick={() => enviarWhatsapp()} disabled={enviando}>{enviando ? '⟳ Enviando...' : '📱 WhatsApp'}</button>
                      </>
                    )}
                  </div>
                  {msgGerada && <div style={S.msgBox}>{msgGerada}</div>}
                </>
              )}
            </div>

            <div style={S.modalFooter}>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button style={S.cancelBtn} onClick={() => { setModal(false); resetForm() }}>Cancelar</button>
                {leadSel && (
                  <button style={{ ...S.cancelBtn, color: 'var(--red)', borderColor: 'rgba(255,59,92,0.3)' }}
                    onClick={() => { excluirLead(leadSel.id, leadSel.name); setModal(false); resetForm() }}>
                    🗑 Excluir
                  </button>
                )}
              </div>
              <button style={S.saveBtn} onClick={salvarLead} disabled={salvando}>
                {salvando ? 'Salvando...' : leadSel ? '✓ Salvar alterações' : '+ Criar Lead'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
