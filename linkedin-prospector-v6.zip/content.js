// content.js — LinkedIn Prospector v6
// Captura dados + envia mensagem no inbox do LinkedIn

function extrairPerfilIndividual() {
  const dados = {}
  const nomeSelectors = ['h1.text-heading-xlarge','h1.inline.t-24','.pv-text-details__left-panel h1','.ph5 h1','main h1']
  for (const sel of nomeSelectors) {
    const el = document.querySelector(sel)
    const txt = el?.innerText?.trim()
    if (txt && txt.length > 2 && !txt.includes('•') && !txt.includes('º')) { dados.name = txt; break }
  }
  const headlineSelectors = ['.text-body-medium.break-words','.pv-text-details__left-panel .text-body-medium','.ph5 .text-body-medium']
  for (const sel of headlineSelectors) {
    const el = document.querySelector(sel)
    if (el?.innerText?.trim()) { dados.headline = el.innerText.trim(); break }
  }
  const locationSelectors = ['.pv-text-details__left-panel span.text-body-small','.ph5 span.text-body-small.inline']
  for (const sel of locationSelectors) {
    const el = document.querySelector(sel)
    const txt = el?.innerText?.trim()
    if (txt && !txt.includes('conexões') && !txt.includes('seguidores') && txt.length > 2) { dados.location = txt; break }
  }
  const empresaSelectors = ['.pv-text-details__right-panel .hoverable-link-text span','.pv-text-details__right-panel span.t-14']
  for (const sel of empresaSelectors) {
    const el = document.querySelector(sel)
    if (el?.innerText?.trim()) { dados.company = el.innerText.trim(); break }
  }
  const fotoSelectors = ['.pv-top-card-profile-picture__image--show','img.pv-top-card-profile-picture__image','img[class*="profile-picture"]']
  for (const sel of fotoSelectors) {
    const el = document.querySelector(sel)
    if (el?.src && !el.src.includes('ghost')) { dados.profile_picture = el.src; break }
  }
  const emailEl = document.querySelector('a[href^="mailto:"]')
  if (emailEl) dados.email = emailEl.href.replace('mailto:','').trim()
  const phoneEl = document.querySelector('a[href^="tel:"]')
  if (phoneEl) dados.phone = phoneEl.href.replace('tel:','').trim()
  const websiteEl = document.querySelector('a[data-field="website_url"]')
  if (websiteEl) dados.website = websiteEl.href
  const bodyTxt = document.body.innerText || ''
  if (bodyTxt.includes('• 1º')||bodyTxt.includes('1st')) dados.connection_degree='1'
  else if (bodyTxt.includes('• 2º')||bodyTxt.includes('2nd')) dados.connection_degree='2'
  else dados.connection_degree='3'
  const mutualMatch = bodyTxt.match(/(\d+)\s+conex[õo]es? em comum/i)
  if (mutualMatch) dados.mutual_connections = mutualMatch[0]
  const seguidoresMatch = bodyTxt.match(/([\d.,]+)\s+seguidores?/i)
  if (seguidoresMatch) dados.followers = seguidoresMatch[0]
  const sobreEl = document.querySelector('#about ~ div .pv-shared-text-with-see-more span') ||
                  document.querySelector('.pv-shared-text-with-see-more span[aria-hidden="true"]')
  if (sobreEl?.innerText) dados.about = sobreEl.innerText.trim().substring(0, 1000)
  dados.linkedin_url = window.location.href.split('?')[0]
  const urlMatch = window.location.pathname.match(/\/in\/([^/]+)/)
  dados.linkedin_id = urlMatch ? urlMatch[1] : ''
  dados.temperature = dados.connection_degree==='1'?'quente':dados.connection_degree==='2'?'morno':'frio'
  dados.source = 'chrome_extension'
  return dados
}

// ==========================================
// ENVIA MENSAGEM NO INBOX DO LINKEDIN
// Simula clique humano no botão "Mensagem"
// ==========================================
async function enviarMensagemLinkedIn(texto) {
  try {
    // Passo 1: Encontra e clica no botão "Mensagem" do perfil
    const botoesMsg = Array.from(document.querySelectorAll('button, a')).filter(el => {
      const txt = el.innerText?.trim().toLowerCase()
      return txt === 'mensagem' || txt === 'message' || txt === 'enviar mensagem'
    })

    if (botoesMsg.length === 0) {
      return { sucesso: false, erro: 'Botão "Mensagem" não encontrado. Você precisa estar conectado ao lead (1º grau) ou no perfil dele.' }
    }

    botoesMsg[0].click()
    await esperar(1500)

    // Passo 2: Encontra a caixa de texto do chat
    const camposTexto = [
      '.msg-form__contenteditable',
      '[data-placeholder="Escreva uma mensagem..."]',
      '[data-placeholder="Write a message..."]',
      '.msg-form__msg-content-container [contenteditable]',
      '[role="textbox"]'
    ]

    let campo = null
    for (const sel of camposTexto) {
      campo = document.querySelector(sel)
      if (campo) break
    }

    // Aguarda mais se não encontrou ainda
    if (!campo) {
      await esperar(1500)
      for (const sel of camposTexto) {
        campo = document.querySelector(sel)
        if (campo) break
      }
    }

    if (!campo) {
      return { sucesso: false, erro: 'Campo de mensagem não encontrado. Tente novamente.' }
    }

    // Passo 3: Foca no campo e digita a mensagem
    campo.focus()
    await esperar(300)

    // Usa clipboard para colar (mais confiável que simular teclas)
    const textoOriginal = await navigator.clipboard.readText().catch(() => '')
    await navigator.clipboard.writeText(texto)
    await esperar(200)

    // Simula Ctrl+V
    campo.dispatchEvent(new KeyboardEvent('keydown', { key: 'v', ctrlKey: true, bubbles: true }))
    document.execCommand('paste')
    await esperar(500)

    // Se clipboard não funcionou, tenta inserir diretamente
    if (!campo.innerText?.trim()) {
      campo.innerText = texto
      campo.dispatchEvent(new Event('input', { bubbles: true }))
      await esperar(300)
    }

    // Restaura clipboard original
    if (textoOriginal) await navigator.clipboard.writeText(textoOriginal).catch(() => {})

    return { sucesso: true, mensagem: 'Mensagem inserida! Revise e clique Enviar.' }

  } catch (err) {
    return { sucesso: false, erro: err.message }
  }
}

function esperar(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

// ==========================================
// EXTRAI LISTA DE BUSCA
// ==========================================
function extrairListaDeBusca() {
  const leads = []
  const vistos = new Set()
  const blacklist = ['messaging','notifications','jobs','feed','mynetwork','search','company','school','groups','events','learning','premium','sales','recruiter','talent']
  const todosLinks = document.querySelectorAll('a[href*="/in/"]')
  todosLinks.forEach(link => {
    try {
      const href = link.href || ''
      if (!href.includes('/in/')) return
      const match = href.match(/\/in\/([a-zA-Z0-9_-]+)/)
      if (!match) return
      const linkedin_id = match[1]
      if (vistos.has(linkedin_id)) return
      if (blacklist.some(b => linkedin_id.includes(b))) return
      if (linkedin_id.length < 3) return
      vistos.add(linkedin_id)
      const lead = { linkedin_id, linkedin_url: `https://www.linkedin.com/in/${linkedin_id}`, source: 'chrome_extension' }
      let container = link
      for (let i = 0; i < 10; i++) {
        container = container.parentElement
        if (!container || container.tagName === 'BODY') break
        const texto = container.innerText || ''
        if (!lead.name) {
          const nomeSpan = link.querySelector('span[aria-hidden="true"]') || link.querySelector('span')
          const nomeTexto = nomeSpan?.innerText?.trim() || link.innerText?.trim()
          if (nomeTexto && nomeTexto.length > 1 && nomeTexto.length < 80 && !nomeTexto.includes('•') && !nomeTexto.includes('º')) lead.name = nomeTexto
        }
        if (!lead.headline) {
          const subs = container.querySelectorAll('[class*="subtitle"],[class*="headline"],.t-14.t-black')
          subs.forEach(s => { const t = s.innerText?.trim(); if (t && t.length > 3 && t.length < 200 && !lead.headline && !t.includes('conexões') && !t.includes('seguidores') && !t.includes('•')) lead.headline = t })
        }
        if (!lead.profile_picture) {
          const img = container.querySelector('img')
          if (img?.src && img.src.startsWith('https') && !img.src.includes('ghost') && (img.src.includes('media') || img.src.includes('profile'))) lead.profile_picture = img.src
        }
        if (!lead.connection_degree) {
          if (texto.includes('• 1º')||texto.includes('1st')) lead.connection_degree='1'
          else if (texto.includes('• 2º')||texto.includes('2nd')) lead.connection_degree='2'
          else if (texto.includes('3º e +')||texto.includes('3rd')||texto.includes('• 3')) lead.connection_degree='3'
        }
        if (!lead.mutual_connections) { const m = texto.match(/(\d+)\s+conex[õo]es? em comum/i); if (m) lead.mutual_connections = m[0] }
        if (lead.name && lead.connection_degree) break
      }
      if (!lead.name || lead.name.length < 2) return
      if (lead.name.toLowerCase().includes('linkedin')) return
      if (lead.name.includes('•') || lead.name.includes('º')) return
      if (lead.headline && !lead.company) {
        if (lead.headline.includes(' · ')) lead.company = lead.headline.split(' · ').pop().trim()
        else if (lead.headline.includes(' na ')) lead.company = lead.headline.split(' na ').pop().split('|')[0].trim()
        else if (lead.headline.includes(' at ')) lead.company = lead.headline.split(' at ').pop().split('|')[0].trim()
      }
      lead.connection_degree = lead.connection_degree || '3'
      lead.temperature = lead.connection_degree==='1'?'quente':lead.connection_degree==='2'?'morno':'frio'
      leads.push(lead)
    } catch(e) {}
  })
  return leads
}

function detectarTipoPagina() {
  const url = window.location.href
  if (url.includes('/search/results/')) return 'busca'
  if (url.includes('/in/')) return 'perfil'
  return 'outro'
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'detectarPagina') {
    const tipo = detectarTipoPagina()
    let preview = null
    if (tipo === 'perfil') { const dados = extrairPerfilIndividual(); preview = { name: dados.name } }
    else if (tipo === 'busca') { const leads = extrairListaDeBusca(); preview = { total: leads.length } }
    sendResponse({ tipo, preview })
  }
  if (request.action === 'extrairPerfil') { sendResponse({ sucesso: true, dados: extrairPerfilIndividual() }) }
  if (request.action === 'extrairBusca') { const leads = extrairListaDeBusca(); sendResponse({ sucesso: true, leads, total: leads.length }) }
  if (request.action === 'enviarMensagemLinkedIn') {
    enviarMensagemLinkedIn(request.texto).then(resultado => sendResponse(resultado))
    return true
  }
  return true
})
