// content.js — LinkedIn Prospector v2.0 — Cromosit IT
// Captura perfil individual E lista de resultados de busca

// ==========================================
// EXTRAI DADOS DE UM PERFIL INDIVIDUAL (/in/nome)
// ==========================================
function extrairPerfilIndividual() {
  const dados = {};

  // Nome
  const nomeSelectors = [
    'h1.text-heading-xlarge',
    'h1.inline.t-24',
    '.pv-text-details__left-panel h1',
    '.ph5 h1',
    'main h1',
    'h1[class*="text-heading"]'
  ];
  for (const sel of nomeSelectors) {
    const el = document.querySelector(sel);
    if (el?.innerText?.trim()) { dados.name = el.innerText.trim(); break; }
  }

  // Headline (cargo)
  const headlineSelectors = [
    '.text-body-medium.break-words',
    '.pv-text-details__left-panel .text-body-medium',
    '.ph5 .text-body-medium',
    'div.text-body-medium'
  ];
  for (const sel of headlineSelectors) {
    const el = document.querySelector(sel);
    if (el?.innerText?.trim()) { dados.headline = el.innerText.trim(); break; }
  }

  // Localização
  const locationSelectors = [
    '.pv-text-details__left-panel span.text-body-small',
    '.ph5 span.text-body-small.inline',
    '.pb2 span.text-body-small'
  ];
  for (const sel of locationSelectors) {
    const el = document.querySelector(sel);
    const txt = el?.innerText?.trim();
    if (txt && !txt.includes('conexões') && !txt.includes('seguidores') && txt.length > 2) {
      dados.location = txt; break;
    }
  }

  // Empresa atual — painel direito do perfil
  const empresaSelectors = [
    '.pv-text-details__right-panel .hoverable-link-text span[aria-hidden="true"]',
    '.pv-top-card--experience-list-item .t-14.t-normal',
    '.pv-text-details__right-panel span[aria-hidden="true"]',
    '.pv-top-card--experience-list li:first-child span[aria-hidden="true"]'
  ];
  for (const sel of empresaSelectors) {
    const el = document.querySelector(sel);
    const txt = el?.innerText?.trim();
    if (txt && txt.length > 1) { dados.company = txt; break; }
  }
  // Fallback: extrai da headline
  if (!dados.company && dados.headline) {
    if (dados.headline.includes(' na '))  dados.company = dados.headline.split(' na ').pop().trim();
    else if (dados.headline.includes(' at '))  dados.company = dados.headline.split(' at ').pop().trim();
    else if (dados.headline.includes(' · '))   dados.company = dados.headline.split(' · ').pop().trim();
  }

  // Email (1º grau com dados públicos)
  const emailEl = document.querySelector('a[href^="mailto:"]');
  if (emailEl) dados.email = emailEl.href.replace('mailto:', '').trim();

  // Telefone
  const phoneEl = document.querySelector('a[href^="tel:"]');
  if (phoneEl) dados.phone = phoneEl.href.replace('tel:', '').trim();

  // Website
  const websiteEl = document.querySelector('a[data-field="website_url"]') ||
                    document.querySelector('.pv-contact-info__contact-type a[href*="http"]');
  if (websiteEl) dados.website = websiteEl.href;

  // Foto de perfil
  const fotoSelectors = [
    '.pv-top-card-profile-picture__image--show',
    'img.pv-top-card-profile-picture__image',
    'img[class*="profile-picture"]',
    '.pv-top-card__photo img'
  ];
  for (const sel of fotoSelectors) {
    const el = document.querySelector(sel);
    if (el?.src && !el.src.includes('ghost')) { dados.profile_picture = el.src; break; }
  }

  // Grau de conexão
  const grauEl = document.querySelector('.dist-value') ||
                 document.querySelector('[class*="distance"] span');
  const grauTxt = grauEl?.innerText?.trim() || '';
  dados.connection_degree = grauTxt.includes('1') ? '1' : grauTxt.includes('2') ? '2' : '3';

  // Conexões em comum
  const commonEl = document.querySelector('.pv-top-card--list .ph5 span.t-12') ||
                   document.querySelector('[class*="shared-connections"] span');
  if (commonEl?.innerText) dados.mutual_connections = commonEl.innerText.trim();

  // Seguidores
  const seguidoresEl = document.querySelector('.pv-top-card--list .t-normal span') ||
                       document.querySelector('[class*="followers"] span');
  if (seguidoresEl?.innerText) dados.followers = seguidoresEl.innerText.trim();

  // Bio/Sobre
  const sobreEl = document.querySelector('.pv-shared-text-with-see-more .visually-hidden') ||
                  document.querySelector('#about ~ div .pv-shared-text-with-see-more span');
  if (sobreEl?.innerText) dados.about = sobreEl.innerText.trim().substring(0, 500);

  // URL e ID
  dados.linkedin_url = window.location.href.split('?')[0];
  const urlMatch = window.location.pathname.match(/\/in\/([^/]+)/);
  dados.linkedin_id = urlMatch ? urlMatch[1] : '';

  // Temperatura automática por grau
  dados.source      = 'chrome_extension';
  dados.temperature = dados.connection_degree === '1' ? 'quente'
                    : dados.connection_degree === '2' ? 'morno'
                    : 'frio';

  return dados;
}

// ==========================================
// EXTRAI LISTA DA PÁGINA DE BUSCA
// ==========================================
function extrairListaDeBusca() {
  const leads = [];

  const cardSelectors = [
    '.reusable-search__result-container',
    '.search-results-container li',
    '[data-chameleon-result-urn]',
    '.entity-result',
    '.search-result'
  ];

  let cards = [];
  for (const sel of cardSelectors) {
    cards = document.querySelectorAll(sel);
    if (cards.length > 0) break;
  }
  if (cards.length === 0) {
    cards = document.querySelectorAll('li.reusable-search__result-container');
  }

  cards.forEach((card) => {
    try {
      const lead = {};

      // Nome — filtra grau de conexão ("• 1º")
      let nomeEl = card.querySelector('.entity-result__title-text a span[aria-hidden="true"]') ||
                   card.querySelector('.app-aware-link span[aria-hidden="true"]') ||
                   card.querySelector('span.entity-result__title-line span[aria-hidden="true"]');

      if (!nomeEl) {
        const spans = card.querySelectorAll('a[href*="/in/"] span');
        for (const s of spans) {
          const txt = s.innerText?.trim() || '';
          const ehGrau = txt.includes('•') || /^\d(º|st|nd|rd)/.test(txt) || txt.length < 3;
          if (txt && !ehGrau) { nomeEl = s; break; }
        }
      }
      lead.name = nomeEl?.innerText?.trim() || '';
      if (!lead.name) return;

      // Headline e empresa — formato "Cargo · Empresa"
      const subtitleEl  = card.querySelector('.entity-result__primary-subtitle');
      const subtitleTxt = subtitleEl?.innerText?.trim() || '';

      if (subtitleTxt.includes(' · ')) {
        const partes = subtitleTxt.split(' · ');
        lead.headline = partes[0].trim();
        lead.company  = partes[1].trim();
      } else {
        lead.headline = subtitleTxt;
        if (lead.headline.includes(' na '))  lead.company = lead.headline.split(' na ').pop().trim();
        else if (lead.headline.includes(' at '))  lead.company = lead.headline.split(' at ').pop().trim();
        else if (lead.headline.includes(' | '))   lead.company = lead.headline.split(' | ').pop().trim();
      }

      // Localização — filtra nomes de conexões
      const locationCandidates = card.querySelectorAll('.entity-result__secondary-subtitle, .t-12.t-black--light, [class*="secondary-subtitle"]');
      for (const el of locationCandidates) {
        const txt = el?.innerText?.trim() || '';
        if (txt && !txt.includes('conexõ') && !txt.includes('seguidor') && !txt.includes('connection') && txt.length > 2) {
          lead.location = txt;
          break;
        }
      }

      // Foto
      const fotoEl = card.querySelector('img.presence-entity__image') ||
                     card.querySelector('img.EntityPhoto-circle') ||
                     card.querySelector('img[class*="profile"]') ||
                     card.querySelector('.entity-result__universal-image img');
      if (fotoEl?.src && !fotoEl.src.includes('ghost') && !fotoEl.src.includes('static')) {
        lead.profile_picture = fotoEl.src;
      }

      // URL e ID
      const linkEl = card.querySelector('a[href*="/in/"]') ||
                     card.querySelector('.app-aware-link[href*="/in/"]');
      if (linkEl?.href) {
        lead.linkedin_url = linkEl.href.split('?')[0];
        const match = lead.linkedin_url.match(/\/in\/([^/]+)/);
        lead.linkedin_id = match ? match[1] : '';
      }

      // Grau de conexão
      const grauEl  = card.querySelector('.dist-value') ||
                      card.querySelector('[class*="distance"]') ||
                      card.querySelector('.entity-result__badge-text');
      const grauTxt = grauEl?.innerText?.trim() || '';
      lead.connection_degree = (grauTxt.includes('1') || grauTxt.includes('1º') || grauTxt.includes('1st')) ? '1'
                             : (grauTxt.includes('2') || grauTxt.includes('2º') || grauTxt.includes('2nd')) ? '2'
                             : '3';

      // Conexões em comum
      const mutualEl = card.querySelector('.entity-result__insights span') ||
                       card.querySelector('[class*="mutual"] span') ||
                       card.querySelector('.member-insights span');
      if (mutualEl?.innerText) lead.mutual_connections = mutualEl.innerText.trim();

      // Snippet / About
      const snippetEl = card.querySelector('.entity-result__summary') ||
                        card.querySelector('[class*="summary"]');
      if (snippetEl?.innerText) lead.about = snippetEl.innerText.trim().substring(0, 300);

      // Botão conectar disponível?
      const connectBtn = card.querySelector('button[aria-label*="Conectar"]') ||
                         card.querySelector('button[aria-label*="Connect"]');
      lead.can_connect = !!connectBtn;

      // Temperatura e fonte
      lead.source      = 'chrome_extension';
      lead.temperature = lead.connection_degree === '1' ? 'quente'
                       : lead.connection_degree === '2' ? 'morno'
                       : 'frio';

      if (lead.name && lead.linkedin_url) leads.push(lead);
    } catch (e) {
      console.warn('Erro ao extrair card:', e);
    }
  });

  return leads;
}

// ==========================================
// DETECTA TIPO DE PÁGINA
// ==========================================
function detectarTipoPagina() {
  const url = window.location.href;
  if (url.includes('/search/results/')) return 'busca';
  if (url.includes('/in/'))             return 'perfil';
  return 'outro';
}

// ==========================================
// ESCUTA MENSAGENS DO POPUP
// ==========================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'detectarPagina') {
    const tipo = detectarTipoPagina();
    let preview = null;
    if (tipo === 'perfil') {
      const dados = extrairPerfilIndividual();
      preview = { name: dados.name, headline: dados.headline };
    } else if (tipo === 'busca') {
      const leads = extrairListaDeBusca();
      preview = { total: leads.length };
    }
    sendResponse({ tipo, preview });
  }

  if (request.action === 'extrairPerfil') {
    const dados = extrairPerfilIndividual();
    sendResponse({ sucesso: true, dados });
  }

  if (request.action === 'extrairBusca') {
    const leads = extrairListaDeBusca();
    sendResponse({ sucesso: true, leads, total: leads.length });
  }

  return true;
});
