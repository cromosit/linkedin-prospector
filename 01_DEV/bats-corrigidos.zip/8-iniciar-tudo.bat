@echo off
echo.
echo ========================================
echo  LinkedIn Prospector - Cromosit IT
echo  Iniciando TUDO (Backend + Frontend)...
echo ========================================
echo.

:: Backend
start "LP Backend - porta 3000" cmd /k "cd /d C:\Users\samue\linkedin-prospector\backend && node server.js"

:: Aguarda backend subir
timeout /t 3 /nobreak > nul

:: Frontend
start "LP Frontend - porta 5173" cmd /k "cd /d C:\Users\samue\linkedin-prospector-frontend && npm run dev"

:: Aguarda frontend e abre navegador
timeout /t 5 /nobreak > nul
start chrome http://localhost:5173

echo.
echo ========================================
echo  Sistema iniciado!
echo  Backend:  http://localhost:3000
echo  Frontend: http://localhost:5173
echo ========================================
echo.
pause
